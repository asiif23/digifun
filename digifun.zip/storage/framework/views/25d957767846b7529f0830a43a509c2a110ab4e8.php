   <!-- ==========Header Section Starts Here========== -->
   <header class="header-section">
    <div class="header-bottom">
        <div class="container">
            <div class="header-wrapper">
                <div class="logo">
                    <a href="index.html">
                        <img src="<?php echo e(asset('assets/web/images/logo/01.png')); ?>" alt="logo" width="200" height="80" style="filter: brightness(200%);">
                    </a>
                </div>
                <div class="menu-area">
                    <ul class="menu">
                        <li>
                            <a href="index.html">Home</a>
                        </li>

                        <li>
                            <a href="#0">About Us</a>
                        </li>
                        <li>
                            <a href="#0">Speakers</a>
                        </li>
                        <li>
                            <a href="contact.html">Contact</a>
                        </li>
                    </ul>
                    <div class="cart-ticket">
                        <a href="pricing-plan.html" class="ticket-btn lab-btn ">
                            <span>Register</span>
                            <span>Tournament</span>
                        </a>
                    </div>

                    <!-- toggle icons -->
                    <div class="header-bar d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- ==========Header Section Ends Here========== --><?php /**PATH I:\BACKUP-PROJECTWEB\digifun\resources\views/layouts/web/navbar.blade.php ENDPATH**/ ?>