<!DOCTYPE html>
<html lang="id">

<head>
    <title>Digifun Festival 2022</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/web/images/x-icon/01.png')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/icofont.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/lightcase.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/swiper.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <?php echo $__env->make('web.registration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- preloader start here -->
    <div class="preloader">
        <div class="preloader-inner">
            <div class="preloader-icon">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- preloader ending here -->


<?php echo $__env->make('layouts.web.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layouts.web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <script src="<?php echo e(asset('assets/web/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/fontawesome.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/circularProgressBar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/lightcase.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/functions.js')); ?>"></script>
</body>

</html><?php /**PATH I:\BACKUP-PROJECTWEB\digifun\resources\views/layouts/web/app.blade.php ENDPATH**/ ?>