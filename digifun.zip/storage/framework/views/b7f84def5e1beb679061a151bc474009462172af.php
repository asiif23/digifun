
  <!-- Modal Free Fire -->
  <div class="modal fade" id="FreeFireModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content" style="background: #00102E">
        <div class="container p-5">
            <div class="accordion" id="accordionExample">
                <div class="steps">
                    <progress id="progress" value=0 max=100></progress>
                    <div class="step-item">
                        <button class="step-button text-center" type="button" data-bs-toggle="collapse"
                            data-bs-target="#ffcollapseOne" aria-expanded="true" aria-controls="ffcollapseOne">
                            1
                        </button>
                        <div class="step-title">
                            Leader
                        </div>
                    </div>
                    <div class="step-item">
                        <button class="step-button text-center collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#fcollapseTwo" aria-expanded="false" aria-controls="fcollapseTwo">
                            2
                        </button>
                        <div class="step-title">
                            Informasi Player
                        </div>
                    </div>
                    <div class="step-item">
                        <button class="step-button text-center collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#ffcollapseThree" aria-expanded="false" aria-controls="ffcollapseThree">
                            3
                        </button>
                        <div class="step-title">
                            Pembayaran
                        </div>
                    </div>
                    <div class="step-item">
                        <button class="step-button text-center collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#ffcollapseFour" aria-expanded="false" aria-controls="ffcollapseFour">
                            4
                        </button>
                        <div class="step-title">
                            Invoice
                        </div>
                    </div>
                </div>
    
                <div class="card" style="background: #01153D;">
                    <div id="headingOne">
                    </div>
                    <div id="ffcollapseOne" class="collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                        <div class="card-body" class="account-wrapper">
                            <form action="" class="account-form" method="POST" anctype="multipart/form">
                                <?php echo csrf_field(); ?>
                                <div class="text-center m-3">
                                    <h5>Detail Informasi Penanggung Jawab</h5>
                                </div>
                                <div class="form-group">
                                    <input type="number" name="category_id" value="2" hidden>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nama" name="name" required>
                                </div>
                                <div class="form-group">
                                    <input type="email" placeholder="Masukkan Email" name="email" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Asal Kota" name="asal_kota" required>
                                </div>
                                <div class="form-group">
                                    <input type="number" placeholder="Masukkan Nomor HP tanpa +62 atau 0" name="no_hp" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nama Tim" name="nama_tim" required>
                                </div>
                                <div class="form-group">
                                    <label for="logo">Masukkan Logo Tim. ( *jika ada )</label>
                                    <input type="file" placeholder="Masukkan Logo" name="logo" required>
                                </div>
                                <div class="card-footer text-end">
                                    <button class="btn lab-btn" type="submit">Next</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card" style="background: #01153D;">
                    <div id="headingTwo">
    
                    </div>
                    <div id="fcollapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div class="card-body" class="account-wrapper">
                            <form action="" class="account-form">
                                <div class="text-center m-3">
                                    <h5>Detail Player (Minimal 5 Orang)</h5>
                                </div>
                                <h6>Player 1</h6>
                                <div class="form-group">
                                    <input type="number" placeholder="Masukkan ID Game" name="id_game" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nick in Game" name="nick" required>
                                </div>
                                <h6>Player 2</h6>
                                <div class="form-group">
                                    <input type="number" placeholder="Masukkan ID Game" name="id_game" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nick in Game" name="nick" required>
                                </div>
                                <h6>Player 3</h6>
                                <div class="form-group">
                                    <input type="number" placeholder="Masukkan ID Game" name="id_game" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nick in Game" name="nick" required>
                                </div>
                                <h6>Player 4</h6>
                                <div class="form-group">
                                    <input type="number" placeholder="Masukkan ID Game" name="id_game" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nick in Game" name="nick" required>
                                </div>
                                <h6>Player 5</h6>
                                <div class="form-group">
                                    <input type="number" placeholder="Masukkan ID Game" name="id_game" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nick in Game" name="nick" required>
                                </div>
                                <h6>Player 6</h6>
                                <div class="form-group">
                                    <input type="number" placeholder="Masukkan ID Game" name="id_game">
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nick in Game" name="nick">
                                </div>
                                <h6>Player 7</h6>
                                <div class="form-group">
                                    <input type="number" placeholder="Masukkan ID Game" name="id_game">
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="Masukkan Nick in Game" name="nick">
                                </div>
                                <div class="card-footer text-end">
                                    <button class="btn lab-btn" type="submit">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card" style="background: #01153D;">
                    <div id="headingThree">
    
                    </div>
                    <div id="ffcollapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                        <div class="card-body">
                            <div class="text-center m-3">
                                <h5>Pilih Metode Pembayaran</h5>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="card" style="background: #01153D;">
                    <div id="headingFour">
    
                    </div>
                    <div id="ffcollapseFour" class="collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                        <div class="card-body">
                            <div class="text-center m-3">
                                <h5>Download Invoices</h5>
                                <span>*sebagai tanda bukti pembayaran</span>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>
  <?php /**PATH I:\BACKUP-PROJECTWEB\digifun\resources\views/web/ff.blade.php ENDPATH**/ ?>